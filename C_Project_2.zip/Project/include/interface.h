#ifndef interface
#define interface


#include "Structures.h"
#include "listing.h"

void startingPoint();




#endif
