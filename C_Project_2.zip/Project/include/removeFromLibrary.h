#ifndef removeFromLib
#define removeFromLib


//#include "listing.h"

void inremoveFromLibrary();

#endif
