#include "Structures.h"
#include "addToLibrary.h"
#include "removeFromLibrary.h"
#include "listing.h"
#include "interface.h"



int main() //program starts here
{

  startingPoint(); //calls function in interface

  return 0;
}
